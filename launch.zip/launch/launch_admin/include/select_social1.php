<?php
require '../functions/class_social1.php';

$sociala = new Sociala();

echo $sociala->selectSociala();
?>
