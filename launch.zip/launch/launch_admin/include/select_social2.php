<?php
require '../functions/class_social2.php';

$socialb = new Socialb();

echo $socialb->selectSocialb();
?>
