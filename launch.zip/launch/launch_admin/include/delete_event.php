<?php
require '../functions/class_event.php';

$event = new Event();

echo $event->deleteEvent();
?>
