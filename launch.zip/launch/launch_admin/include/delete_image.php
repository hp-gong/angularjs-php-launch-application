<?php
require '../functions/class_images.php';

$images = new Images();

echo $images->deleteImage();
?>
