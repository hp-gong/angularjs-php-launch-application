<?php
require '../functions/class_header.php';

$header = new Header();

echo $header->selectHeaders();
?>
