<?php
require '../functions/class_email.php';

$email = new Email();

echo $email->insertEmails();
?>
