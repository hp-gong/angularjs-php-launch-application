<?php
include("include/select_session.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Launch Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

  </head>

  <body>
<?php include 'include/nav.php'; ?>
    <div class="container">
      <div ng-app="myEmailApp" ng-controller="emailcontrol" ng-init="displayEmail()">
        <div id="csvEmail">
        <table class="table table-bordered">
          <thead>
      	  <tr>
          <th style="border: 1px solid black; text-align: center;" scope="col">Email</th>
      	  </tr>
      	  </thead>
      	  <tbody>
             <tr ng-repeat="e in emails">
                 <td style="border: 1px solid black;" align="center">{{e.email}}</td>
                 <input type="hidden" ng-model="email">
            </tr>
          </tbody>
          </table>
          <a id="export" style="display:inline-block;box-sizing:border-box;margin:5px;text-align:center;text-decoration:none;cursor:pointer;background-color:transparent;-webkit-transition:all .25s ease;-moz-transition:all .25s ease;-ms-transition:all .25s ease;-o-transition:all .25s ease;transition:all .25s ease;font-size:12px;font-size:0.9rem;line-height:34px;line-height:0.1rem;min-width:40px;min-width:5rem;padding:16px 15px;border-color:#666;border-width:1px;border-style:solid;border-radius:3.5px; border-color:#387cfd;background-color:#387cfd;color:#f5f5f5;" href="#">Export as CSV</a>
          <input type="hidden" ng-model="id">
          <button ng-click="deleteEmail(e.id)" class="btn btn-danger btn-xs" style="font-size:12px;font-size:0.9rem;">Delete</button>
          </div>
      </div> <!-- myEmailApp end -->
    </div> <!-- container end -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="bootstrap/js/jquery.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Angular JS v1.6.6 -->
    <script src="js/angular.min.js"></script>
    <!-- Ajax -->
    <script src="js/apps1.js"></script>
    <!-- Export -->
    <script src="js/export_email.js"></script>
  </body>

</html>
